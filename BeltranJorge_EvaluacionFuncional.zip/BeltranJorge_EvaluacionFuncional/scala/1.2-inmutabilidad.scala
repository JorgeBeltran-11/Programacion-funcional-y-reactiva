// Case class para representar un préstamo: Inmutable por default en Scala (no se pueden cambiar campos después de crear).
case class Prestamo(
  id: Int,                    // Línea 2: ID único del préstamo (Int inmutable).
  usuarioId: Int,             // Línea 3: ID del usuario (Int).
  libroId: Int,               // Línea 4: ID del libro (Int).
  activo: Boolean,            // Línea 5: Estado activo/inactivo (Boolean; clave para inmutabilidad).
  fechaPrestamo: String       // Línea 6: Fecha como String (inmutable).
)

// Función principal: Crea una NUEVA lista de préstamos sin mutar la original.
// Esto demuestra inmutabilidad: Transforma datos sin side-effects.
def devolverLibro(prestamos: List[Prestamo], prestamoId: Int): List[Prestamo] = {
  prestamos.map {             // Línea 10: 'map' es una operación funcional de orden superior.
                              // Crea una NUEVA List aplicando una transformación a cada elemento.
                              // No toca la lista original (inmutabilidad garantizada).
    case p if p.id == prestamoId => 
                              // Línea 12: Pattern matching con 'if' (guard): Si el ID coincide...
      p.copy(activo = false)  // Línea 13: 'copy' crea un NUEVO objeto Prestamo con solo 'activo' cambiado a false.
                              // No muta 'p' original (inmutabilidad: evita p.activo = false, que fallaría en case class).
    case p => p                // Línea 14: Caso default: Retorna el objeto original sin cambios (eficiente, reutiliza referencia).
  }                           // Línea 15: Cierra el map; retorna nueva List.
}

// Object principal: Contenedor para código ejecutable (necesario para compilar scripts en Scala).
// Sin esto, 'val' y 'println' causan "Illegal start of top level definition".
object InmutabilidadMain {
  def main(args: Array[String]): Unit = {  // Línea 19: Entry point estándar (como main en otros lenguajes).
    // Datos de ejemplo: Lista inmutable de préstamos.
    val prestamos = List(      // Línea 21: 'List' crea colección inmutable (no se puede agregar/eliminar post-creación).
      Prestamo(1, 101, 201, true, "2024-01-15"),   // Línea 22: Instancia 1: Activo=true.
      Prestamo(2, 102, 202, true, "2024-01-20")    // Línea 23: Instancia 2: Activo=true.
    )

    // Ejemplo de uso: Llama a la función.
    val prestamosActualizados = devolverLibro(prestamos, 1)  // Línea 26: Crea NUEVA lista; solo cambia el primero.

    // Outputs para verificar inmutabilidad.
    println(s"Original: $prestamos")                    // Línea 28: Muestra original (sigue con true).
                                                        // Interpolación 's' es pura (no side-effects).
    println(s"Actualizado: $prestamosActualizados")     // Línea 29: Muestra nueva lista (con false en ID=1).
    println(s"Original intacto: ${prestamos.head.activo}")  // Línea 30: Prueba: head (primer elemento) sigue true.
                                                            // Demuestra que original NO cambió.
  }
}