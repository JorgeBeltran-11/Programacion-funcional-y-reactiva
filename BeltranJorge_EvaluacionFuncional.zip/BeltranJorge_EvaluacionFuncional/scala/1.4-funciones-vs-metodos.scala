// Case class para Libro: Inmutable, con campos fijos (ideal para FP: datos no cambian).
case class Libro(
  id: Int,                    // Línea 2: ID único (Int inmutable).
  titulo: String,             // Línea 3: Título del libro.
  autor: String,              // Línea 4: Autor (usado para filtrado).
  categoria: String           // Línea 5: Categoría (e.g., para grouping futuro).
)

// Clase Biblioteca: Representa encapsulación OOP con toque FP (método usa filter inmutable).
class Biblioteca(libros: List[Libro]) {
  // Método: Atado a la instancia de la clase (accede implícitamente a 'this.libros').
  def buscarPorAutor(autor: String): List[Libro] = {  // Línea 10: 'def' dentro de class; retorna List inmutable.
    libros.filter(_.autor == autor)                   // Línea 11: filter crea NUEVA List (inmutable); '_' es wildcard para lambda concisa (p => p.autor == autor).
                                                      // Puro: Mismo input → mismo output; no side-effects.
  }
}

// Object para funciones utilitarias: Singleton para funciones standalone (no atadas a instancias).
object FuncionesBiblioteca {
  // Función: Independiente, toma todos params explícitamente (más flexible y pura que métodos).
  def buscarPorAutor(libros: List[Libro], autor: String): List[Libro] = {  // Línea 17: 'def' en object; no accede a 'this'.
    libros.filter(libro => libro.autor == autor)                          // Línea 18: filter con lambda explícita (libro => ...); misma lógica, pero genérica.
                                                                          // Ventaja: Reutilizable sin crear instancia.
  }
}

// Object principal: Contenedor para código ejecutable (evita error "Illegal start of top level definition").
// Necesario para compilar y correr scripts en Scala.
object FuncVsMetodosMain {
  def main(args: Array[String]): Unit = {  // Línea 24: Entry point (como main en Java/C); 'Unit' = void.
    // Datos de ejemplo: Lista inmutable de libros.
    val libros = List(                    // Línea 26: 'val' inmutable; List es colección persistente (no mutable).
      Libro(1, "Clean Code", "Uncle Bob", "Programacion"),  // Línea 27: Instancia 1.
      Libro(2, "Refactoring", "Martin", "Programacion")     // Línea 28: Instancia 2 (autor diferente para prueba).
    )

    // Ejemplo de uso del MÉTODO (en instancia de clase).
    val biblio = new Biblioteca(libros)   // Línea 31: Crea instancia; pasa lista (inmutable, no copia).
    println(biblio.buscarPorAutor("Uncle Bob"))  // Línea 32: Llama método; output: List(Libro(1,Clean Code,Uncle Bob,Programacion))
                                                // Demuestra: Método encapsula acceso a 'libros' (OOP).

    // Ejemplo de uso de la FUNCIÓN (standalone).
    println(FuncionesBiblioteca.buscarPorAutor(libros, "Martin"))  // Línea 34: Llama función; output: List(Libro(2,Refactoring,Martin,Programacion))
                                                                  // Demuestra: Función no necesita instancia; más directa.

    /*
     * Diferencia clave (para reflexión/defensa):
     * - MÉTODO: Member de class (estado implícito via 'this.libros'); útil para encapsulación OOP+FP.
     *   Cuándo usar: Cuando necesitas contexto de objeto (e.g., múltiples métodos en Biblioteca).
     *   Testing: Requiere mock de instancia (más setup).
     * - FUNCIÓN: Standalone en object (todo explícito); promueve reutilización y pureza (fácil de componer).
     *   Cuándo usar: Para utils genéricas (e.g., filtros reutilizables en múltiples clases).
     *   Testing: Más fácil (solo pasa params; no mocks).
     * En biblioteca: Método para queries de instancia; función para pipelines funcionales (e.g., compose con map).
     */
  }
}