// scala/2.4-tuplas-analisis.scala

// 1. Definición del case class (OBLIGATORIO, si no existe → error de compilación)
case class Prestamo(
  id: Int,
  libroId: Int,
  usuarioId: Int,
  fechaPrestamo: String,
  activo: Boolean
)

// 2. Función principal que retorna una TUPLA (Int, Int, Double)
def estadisticasUsuario(prestamos: List[Prestamo], usuarioId: Int): (Int, Int, Double) = {
  val delUsuario = prestamos.filter(_.usuarioId == usuarioId)   // Línea 1: Filtra préstamos del usuario
  val total      = delUsuario.length                            // Línea 2: Total de préstamos del usuario
  val activos    = delUsuario.filter(_.activo).length           // Línea 3: Solo los activos
  val meses      = 12.0                                         // Asumimos análisis anual
  val promedio   = if (total > 0) total / meses else 0.0        // Línea 4: Promedio mensual (evita división por cero)
  
  (total, activos, promedio) // Línea 5: Retorna tupla inmutable
}

// 3. Object con nombre ÚNICO (para que no choque con los otros Main)
object TuplasMain {
  def main(args: Array[String]): Unit = {
    // Datos de ejemplo
    val prestamos = List(
      Prestamo(1, 1, 101, "2024-01", true),
      Prestamo(2, 2, 101, "2024-02", false),
      Prestamo(3, 3, 101, "2024-03", true),
      Prestamo(4, 4, 102, "2024-01", true)
    )

    // Prueba con usuario 101 → debe devolver (3, 2, 0.25)
    val resultado = estadisticasUsuario(prestamos, 101)
    println(s"Usuario 101: $resultado")  // → (3,2,0.25)

    // Bonus: desestructuración de tupla (muy útil en defensa)
    val (total, activos, promedio) = estadisticasUsuario(prestamos, 101)
    println(s"Total: $total, Activos: $activos, Promedio mensual: $promedio")
  }
}