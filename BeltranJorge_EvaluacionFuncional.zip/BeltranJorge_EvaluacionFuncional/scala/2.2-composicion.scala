// 2.2-composicion.scala  ← NOMBRE DEL ARCHIVO

// Funciones puras
def aplicarDescuento(precio: Double): Double = precio * 0.85   // 15% off

def aplicarImpuesto(precio: Double): Double = precio * 1.12    // 12% IVA

def redondearPrecio(precio: Double): String = f"${precio}%.2f"

// ←←← AQUÍ ESTÁ LA SOLUCIÓN: usa un nombre diferente en cada archivo
object ComposicionMain {     // <--- Cambiado de "Main" a "ComposicionMain"
  def main(args: Array[String]): Unit = {
    // Composición con andThen (flujo: descuento → impuesto → formato)
    val procesarPrecioFinal = 
      aplicarDescuento andThen aplicarImpuesto andThen redondearPrecio

    println(procesarPrecioFinal(100.0))   // → 95.20
    println(procesarPrecioFinal(200.0))   // → 190.40 (prueba que es pura)
  }
}