**PREGUNTAS:**

**1. ¿Qué ventajas encontraste al usar programación funcional en este caso de uso? ¿Qué desafíos enfrentaste al evitar la mutación?**
La programación funcional (FP) enfatiza funciones puras, inmutabilidad y composición, contrastando con imperativa (pasos secuenciales, mutación). En el proyecto, el filtrado imperativo (1.1) usa loops y push (eficiente pero propenso a bugs), mientras declarativo usa filter/sort (legible, thread-safe). Ventajas FP: Menos errores (no estado compartido), fácil testing (puras). Desafíos: Curva aprendizaje (pensar "qué" no "cómo"); overhead en perf (copias de datos). Ejemplo: En biblioteca, FP evita race conditions en actualizaciones concurrentes.

**2. ¿En qué situaciones preferirías programación funcional sobre imperativa y viceversa?**
Prefiere FP cuando: Datos inmutables (e.g., reports en 1.5), paralelismo (map en Scala), o composición (2.2). Imperativa para: I/O pesado o perf crítica (e.g., loops en hot paths). Híbrido ideal: JS/Scala permiten mix (métodos en 1.4). Crítica: FP no elimina complejidad (composición profunda puede obscurecer); pero en reactiva (futura fase), FP brilla con streams inmutables.

**3. Diferencias entre JavaScript y Scala para programación funcional. ¿Cuál te pareció más adecuado y por qué?**
JS: Dinámico, prototipal; FP via Array methods (filter/map) y closures (2.1). Fácil para web, pero garbage collection puede pausar en grandes lists. Scala: Estático, híbrido OOP/FP; case classes/tuplas (2.4) y andThen (2.2) nativos. Más robusto (type safety previene errores en runtime), pero verbose. JS para prototipos rápidos; Scala para producción (e.g., Akka reactivo). En proyecto: JS para UI reports, Scala para backend inmutable.

**4. ¿Cómo aplicarías estos conceptos en un proyecto real? Da ejemplos concretos.**
En proyectos reales: Netflix usa Scala FP para streams reactivos (inmutabilidad en recomendaciones). En biblioteca digital: Funcs puras para multas (1.3) evitan overcharges; reduce para analytics (1.5) escala a millones de préstamos. Mi takeaway: FP fomenta código mantenible; lo aplicaré en tesis de IA (modelos puros para training).