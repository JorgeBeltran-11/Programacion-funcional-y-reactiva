// Función pura: Calcula días de retraso (solo inputs, no side-effects).
function calcularDiasRetraso(fechaPrestamo, fechaDevolucion, diasPermitidos) {
  const prestamo = new Date(fechaPrestamo); // Línea 1: Crea Date inmutable de input (no usa Date.now()).
  const devolucion = new Date(fechaDevolucion); // Línea 2: Similar para fechaDevolucion.
  const diferenciaMs = devolucion - prestamo; // Línea 3: Resta Dates (da ms); determinístico (mismo input → mismo ms).
  const diasTotales = Math.floor(diferenciaMs / (1000 * 60 * 60 * 24)); // Línea 4: Convierte a días (floor para entero).
  return Math.max(0, diasTotales - diasPermitidos); // Línea 5: Retraso = total - permitidos (max evita negativos); puro.
}

// Función pura: Calcula multa basada solo en retraso.
function calcularMulta(diasRetraso) {
  return (diasRetraso * 0.50).toFixed(2); // Línea 1: Multiplica y formatea (toFixed crea string nuevo); no side-effects.
}

// Ejemplo
console.log(calcularDiasRetraso("2024-01-01", "2024-01-20", 14)); // "6"
/*
  ¿Por qué puras? Ambas toman solo params, retornan valor fijo (determinismo), no mutan globals ni I/O (e.g., no console.log).
  Si usas Date.now(): No pura (depende de tiempo real; tests fallarían en ejecuciones diferentes).
  Ventajas testing: Mockea inputs fácilmente (e.g., Jest: expect(calcularDiasRetraso('2024-01-01', '2024-01-20', 14)).toBe(6)).
*/
console.log(calcularMulta(6)); // "3.00"