// Datos de ejemplo (extiendo para reporte)
const libros = [ /* ... del 1.1 */ ];
const prestamos = [
  { usuarioId: 101, libroId: 1, activo: true },
  { usuarioId: 102, libroId: 1, activo: false },
  { usuarioId: 101, libroId: 3, activo: true },
  // ... más para simular
];
const usuariosActivos = prestamos.reduce((acc, p) => ({ ...acc, [p.usuarioId]: (acc[p.usuarioId] || 0) + 1 }), {});

// Genera reporte usando solo map/filter/reduce/sort (no loops).
function generarReporteCompleto(libros, prestamos) {
  // librosPorCategoria: reduce para contar por cat.
  const librosPorCategoria = libros.reduce((acc, libro) => { // Línea 1: reduce acumula objeto (inicial {} implícito).
    acc[libro.categoria] = (acc[libro.categoria] || 0) + 1; // Línea 2: Incrementa count (crea nuevo acc cada iteración via spread implícito).
    return acc;
  }, {});

  // usuariosMasActivos: top 5 (reduce para counts, sort/slice).
  const counts = prestamos.reduce((acc, p) => { // Línea 3: reduce para map usuario:count.
    acc[p.usuarioId] = (acc[p.usuarioId] || 0) + (p.activo ? 1 : 0);
    return acc;
  }, {});
  const topUsuarios = Object.entries(counts)
    .sort(([,a], [,b]) => b - a) // Línea 4: sort descendente por count.
    .slice(0, 5) // Línea 5: top 5.
    .map(([id]) => parseInt(id)); // Línea 6: extrae IDs.

  // librosMasPrestados: reduce para counts por libro, sort top 3.
  const libroCounts = prestamos.reduce((acc, p) => { // Línea 7: similar, count por libroId.
    acc[p.libroId] = (acc[p.libroId] || 0) + 1;
    return acc;
  }, {});
  const topLibros = Object.entries(libroCounts)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 3)
    .map(([id]) => parseInt(id));

  // tasaPrestamosActivos: filter + length / total.
  const totalPrestamos = prestamos.length; // Línea 8: length (O(1)).
  const activos = prestamos.filter(p => p.activo).length; // Línea 9: filter crea subarray, length.
  const tasa = ((activos / totalPrestamos) * 100).toFixed(2); // Línea 10: calcula %.

  return {
    librosPorCategoria,
    usuariosMasActivos: topUsuarios,
    librosMasPrestados: topLibros,
    tasaPrestamosActivos: `${tasa}%`
  };
}

// Ejemplo
console.log(generarReporteCompleto(libros, prestamos));
/*
{ librosPorCategoria: { Programacion: 3, Matematicas: 1 },
  usuariosMasActivos: [101, 102],
  librosMasPrestados: [1, 3],
  tasaPrestamosActivos: "50.00%" }
*/