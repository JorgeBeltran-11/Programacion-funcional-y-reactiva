// 2.3-recomendaciones.js

function generarRecomendaciones(libros, categoriasFavoritas) {
  return libros
    .filter(libro => categoriasFavoritas.includes(libro.categoria))
    .map(libro => ({
      ...libro,
      score: 
        (libro.prestamosCount || 0) * 2 +
        (libro.anio >= 2020 ? 5 : 0) +
        (libro.rating || 0) * 10
    }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 10);
}

// Datos de ejemplo
const libros = [
  { id: 1, titulo: "Clean Code", categoria: "Programacion", anio: 2008, prestamosCount: 45, rating: 4.8 },
  { id: 2, titulo: "Design Patterns", categoria: "Programacion", anio: 1994, prestamosCount: 38, rating: 4.7 },
  { id: 3, titulo: "IA Moderna", categoria: "Programacion", anio: 2023, prestamosCount: 72, rating: 4.9 },
  { id: 4, titulo: "Cálculo", categoria: "Matematicas", anio: 2018, prestamosCount: 15, rating: 4.2 },
  { id: 5, titulo: "Programación Reactiva", categoria: "Programacion", anio: 2022, prestamosCount: 60, rating: 4.6 }
];

const categoriasFavoritas = ["Programacion"];

console.log(generarRecomendaciones(libros, categoriasFavoritas));