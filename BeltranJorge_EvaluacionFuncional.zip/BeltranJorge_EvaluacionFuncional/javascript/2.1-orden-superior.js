// Datos
const libros = [ /* ... */ ];

// Closure: Retorna función para filter basada en criterio.
function crearFiltrador(criterio) {
  return function(libro) { // Línea 1: Inner func (closure) captura 'criterio' (scope cerrado).
    return Object.entries(criterio).every(([key, value]) => libro[key] === value); // Línea 2: every chequea todas keys (e.g., {categoria: "Programacion"}); pura.
  };
}

// Función que recibe otra como param.
function procesarPrestamos(prestamos, estrategia) {
  return prestamos.map(estrategia); // Línea 1: map aplica 'estrategia' (func param) a cada uno (compone dinámicamente).
}

// Ejemplos
const filtrarProgramacion = crearFiltrador({ categoria: "Programacion" });
console.log(libros.filter(filtrarProgramacion)); // Libros de Programacion

const duplicarDias = p => ({ ...p, dias: (p.dias || 0) * 2 }); // Estrategia ejemplo.
console.log(procesarPrestamos([{dias: 5}], duplicarDias)); // [{dias: 10}]