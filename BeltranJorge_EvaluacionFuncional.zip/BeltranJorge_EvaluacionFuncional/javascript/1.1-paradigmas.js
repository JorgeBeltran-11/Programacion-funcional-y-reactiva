// Datos de ejemplo
const libros = [
  { id: 1, titulo: "Clean Code", categoria: "Programacion", anio: 2008, prestado: false },
  { id: 2, titulo: "Design Patterns", categoria: "Programacion", anio: 1994, prestado: true },
  { id: 3, titulo: "Refactoring", categoria: "Programacion", anio: 1999, prestado: false },
  { id: 4, titulo: "Calculus", categoria: "Matematicas", anio: 2010, prestado: false }
];

// Imperativa: Usa loops y mutación para filtrar libros no prestados de "Programacion" y ordenar por año.
function filtrarLibrosImperativo(libros, categoria) {
  const resultado = []; // Línea 1: Crea un array vacío para almacenar resultados (mutación implícita al push).
  for (let i = 0; i < libros.length; i++) { // Línea 2: Loop for tradicional; itera manualmente (estilo imperativo: controla el flujo paso a paso).
    if (libros[i].categoria === categoria && !libros[i].prestado) { // Línea 3: Verifica condición (disponible y categoría); accede directamente a índices.
      resultado.push(libros[i]); // Línea 4: Mutación: agrega al array (cambia el estado de 'resultado').
    }
  }

  // Ordenar por año (muta el array resultado).
  for (let i = 0; i < resultado.length - 1; i++) { // Línea 5: Segundo loop para bubble sort simple (imperativo: maneja orden manual).
    for (let j = 0; j < resultado.length - i - 1; j++) {
      if (resultado[j].anio > resultado[j + 1].anio) { // Línea 6: Compara años y swap (mutación).
        [resultado[j], resultado[j + 1]] = [resultado[j + 1], resultado[j]]; // Línea 7: Intercambia elementos (cambia estado).
      }
    }
  }
  return resultado; // Línea 8: Retorna el array mutado.
}

// Declarativa: Usa filter y sort (funcionales, sin mutación).
function filtrarLibrosDeclarativo(libros, categoria) {
  return libros
    .filter(libro => libro.categoria === categoria && !libro.prestado) // Línea 1: filter crea nuevo array filtrando (inmutable: no toca original; lambda pura).
    .sort((a, b) => a.anio - b.anio); // Línea 2: sort crea nuevo array ordenado (inmutable; compara sin mutar).
}

// Imprimir resultados
console.log("Imperativo:", filtrarLibrosImperativo(libros, "Programacion")); // [{id:1,...}, {id:3,...}]
console.log("Declarativo:", filtrarLibrosDeclarativo(libros, "Programacion")); // Mismo resultado, pero sin mutación.