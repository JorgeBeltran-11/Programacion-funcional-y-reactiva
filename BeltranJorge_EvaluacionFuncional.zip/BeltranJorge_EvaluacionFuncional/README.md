# Evaluación Programación Funcional - Jorge Bryan Beltrán Navarro

## Información del Estudiante
- **Nombre:** Jorge Bryan Beltrán Navarro
- **Cédula/ID:** 1501092207
- **Fecha de entrega:** 2025-11-28

## Instrucciones de Ejecución
1. Yo trabajo con visual studio code.
2. Dentro de visual studio code tengo instalado la extension "metals" que sirve para trabajar con el lenguaje Scala, y para javascript tengo instalado "node.js 24.11.0".
3. Dentro de visual studio code tengo instalado una extension llamada "Code Runner" que recomiendo instalar para ejecutar cualquier tipo de archivo.
Con esta extension ejecuto los programas de javascript y scala de una manera facil y rapida.

### JavaScript
1. Tener instalado la extension "Code Runner".
# Para ejecutar los archivos JavaScript:
1. Entrar a la carpeta javascript.
2. Seleccionar un archivo javascript.
2. Dar clic en un boton llamado "Run Code" que suele estar arriba.
3. Se abrira una consola o terminal, ahi se vera el resultado del programa.
4. !Eso es todo!.

### Scala
1. Tener instalado la extension "Code Runner".
# Para ejecutar los archivos Scala:
1. Entrar a la carpeta scala.
2. Seleccionar un archivo scala.
2. Dar clic en un boton llamado "Run Code" que suele estar arriba.
3. Se abrira una consola o terminal, ahi se vera el resultado del programa.
4. !Eso es todo!.

### Dependencias
1. Node.js (para JavaScript)
2. Extension "Metals"  (para Scala)
3. Extension "Code Runner" (para ejecutar cualquier archivo)

### Estructura del Proyecto
1. El proyecto se encuentra en formato .zip
2. Dentro del .zip esta todo el proyecto
3. Existen 2 carpetas, una llamada "javascript", y la otra llamada "scala"
4. Dentro de la carpeta javascript estan todos los archivos javascript
5. Dentro de la carpeta scala estan todos los archivos scala
6. Dentro de la raiz del proyecto esta el archivo llamado README.md que indica la estructura del proyecto, esta otro archivo llamado REFLEXION.md, este archivo es la respuesta del ejercicio 2.5 denominado "documento de reflexion".
7. Dentro de la raiz del proyecto estan varias carpetas, por ejemplo, .bsp, .metals, .scala-build, .vscode, estas carpetas se crearon automaticamente al crear o trabajar con los archivos javascript y scala, visual studio code los creo automaticamente, son librerias o dependencias necesarias para que los programas se ejecuten correctamente.
8. Dentro de la carpeta scala estan dos carpetas mas llamadas .bsp y .scala-build, estas carpetas vs code las creo para poder trabajar con normalidad cuando se trabaja con archivos .scala.